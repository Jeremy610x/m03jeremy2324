/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author Dario
 */
public class Calc {

    double Num1;
    double Num2;
    
    public Calc(double Num1, double Num2){
        this.Num1 = Num1;
        this.Num2 = Num2;
    }
    
    public double Sumar()
    {
        return (double) Num1+Num2;
    }
    
    
    public double Restar()
    {
        return (double) Num1-Num2;
    }
    
    public double Multiplicar()
    {
        return (double) Num1*Num2;
    }
    
    public double Dividir()
    {
        return (double) Num1/Num2;
    }
}
