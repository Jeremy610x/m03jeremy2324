/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exercici2;

/**
 *
 * @author jepa2698
 */
public class Exercici2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //declara variables
         int lado;
        int perimetro;
        
        //informar valor  a la variable
        lado =5;
        
        
        //calcular perimetro
        perimetro = lado * 4;
        //mostrar resultado por pantalla
        System.out.println("El perimetro es " + perimetro);
        
    }
    
}
